========
Overview
========

This archive contains the ground truth corpus for the "Sexual Predator Identification" task of the PAN 2012 Lab, held in conjunction with the CLEF 2012 conference.

Find out about all the details at http://pan.webis.de.


===========================
Files Description
===========================
There are two files in this archive.

The file pan12-sexual-predator-identification-groundtruth-problem1 contains 254 ids of authors considered perverted (one per line).
The file pan12-sexual-predator-identification-groundtruth-problem2.txt contains 6478 conversations id and lines id of those line considered suspicious (of a perverted behavior) in a particular conversation.
